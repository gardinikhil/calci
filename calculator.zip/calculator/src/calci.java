import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class calci {
    private double total1=0.0;
    private double total2=0.0;
    private char opera;
    private JPanel cal;
    private JTextField TextField;
    private JButton a7Button;
    private JButton a4Button;
    private JButton a5Button;
    private JButton a2Button;
    private JButton a8Button;
    private JButton a0Button;
    private JButton a6Button;
    private JButton a9Button;
    private JButton a3Button;
    private JButton a1Button;
    private JButton button11;
    private JButton button12;
    private JButton button13;
    private JButton button14;
    private JButton xButton;
    private JButton cButton;
    private JButton button1;

    private void Getopera(String btnText)
    {
        opera=btnText.charAt(0);
        total1=total1 + Double.parseDouble(TextField.getText());
        TextField.setText("");
    }

    public calci() {
        a1Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button1text=TextField.getText()+a1Button.getText();
                TextField.setText(button1text);
            }
        });


        a2Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button2text=TextField.getText()+a2Button.getText();
                TextField.setText(button2text);
            }
        });


        a3Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button3text=TextField.getText()+a3Button.getText();
                TextField.setText(button3text);
            }
        });


        a4Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button4text=TextField.getText()+a4Button.getText();
                TextField.setText(button4text);
            }
        });

        a5Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button5text=TextField.getText()+a5Button.getText();
                TextField.setText(button5text);
            }
        });


        a6Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button6text=TextField.getText()+a6Button.getText();
                TextField.setText(button6text);
            }
        });


        a7Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button7text=TextField.getText()+a7Button.getText();
                TextField.setText(button7text);
            }
        });


        a8Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button8text=TextField.getText()+a8Button.getText();
                TextField.setText(button8text);
            }
        });


        a9Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button9text=TextField.getText()+a9Button.getText();
                TextField.setText(button9text);
            }
        });

        a0Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button0text=TextField.getText()+a0Button.getText();
                TextField.setText(button0text);
            }
        });


        //code for addition
        button12.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button_text=button12.getText();
                        Getopera(button_text);
            }
        });


        //code for equals
        button14.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                switch (opera){
                    case '+':
                        total2=total1 + Double.parseDouble(TextField.getText());
                        break;
                    case '-':
                        total2=total1 - Double.parseDouble(TextField.getText());
                        break;
                    case 'x':
                        total2=total1 * Double.parseDouble(TextField.getText());
                        break;
                    case '/':
                        total2=total1 / Double.parseDouble(TextField.getText());
                        break;
                }
                TextField.setText(Double.toString(total2));
                total1=0;
            }
        });

        //code for clear all
        cButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                total2=0;
                TextField.setText("");
            }
        });


        //code for point
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if(TextField.getText().equals("")) {
                    TextField.setText("0.");
                }
                else if (TextField.getText().contains(".")){
                    button1.setEnabled(false);
                }
                else{
                    String btnpoint=TextField.getText() + button1.getText();
                    TextField.setText(btnpoint);
                }
               }
        });

        //code for subtract
        button11.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button_text=button11.getText();
                Getopera(button_text);
            }
        });

        //code for multiplication
        xButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button_text=xButton.getText();
                Getopera(button_text);
            }
        });


        //code for division
        button13.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String button_text=button13.getText();
                Getopera(button_text);
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("calci");
        frame.setContentPane(new calci().cal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
